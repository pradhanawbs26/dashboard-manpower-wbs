/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FTWRecord, FTWStatus } from '../types';

/**
 * Indonesian month map for parsing dates like "26 September 2026"
 */
const INDO_MONTH_MAP: Record<string, string> = {
  januari: '01', jan: '01',
  februari: '02', feb: '02',
  maret: '03', mar: '03',
  april: '04', apr: '04',
  mei: '05', may: '05',
  juni: '06', jun: '06',
  juli: '07', jul: '07',
  agustus: '08', ags: '08', agu: '08',
  september: '09', sep: '09', sept: '09',
  oktober: '10', okt: '10', oct: '10',
  november: '11', nov: '11',
  desember: '12', des: '12', dec: '12'
};

/**
 * Normalizes NIK or NRP string for clean comparisons across disparate database schemas.
 * Trims whitespace, uppercases, removes punctuation/hyphens.
 */
export function normalizeNIK(nik?: string): string {
  if (!nik) return '';
  return String(nik).trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

export interface NikValidationResult {
  isValid: boolean;
  cleanedNik: string;
  hasLeadingZero: boolean;
  isAbnormalLength: boolean;
  hasNonDigits: boolean;
  digitCount: number;
  suggestedNik: string;
  errorMessage?: string;
  noticeMessage?: string;
}

/**
 * Validates NIK strictly according to PT. WBS standard rules:
 * 1. Exactly 9 digits.
 * 2. Digits only (no letters/symbols).
 * 3. MUST NOT start with zero (0).
 * 
 * If starts with 0: shows prompt notice to enter without leading zero.
 * If abnormal length: gives strict K3 warning and forbids FTW submission.
 */
export function validateNikStrict(rawNik: string): NikValidationResult {
  const trimmed = String(rawNik || '').trim();
  if (!trimmed) {
    return {
      isValid: false,
      cleanedNik: '',
      hasLeadingZero: false,
      isAbnormalLength: false,
      hasNonDigits: false,
      digitCount: 0,
      suggestedNik: '',
      errorMessage: 'NIK wajib diisi.'
    };
  }

  // Strip prefix NIK or NRP if entered
  const upper = trimmed.toUpperCase();
  const withoutPrefix = upper.replace(/^(NIK|NRP)[-\s]*/, '');

  const hasLeadingZero = withoutPrefix.startsWith('0');
  const nonDigits = withoutPrefix.replace(/[0-9]/g, '');
  const hasNonDigits = nonDigits.length > 0;
  const digitsOnly = withoutPrefix.replace(/[^0-9]/g, '');
  const strippedZero = digitsOnly.replace(/^0+/, '');
  const isAbnormalLength = digitsOnly.length !== 9;

  // Case 1: Starts with zero
  if (hasLeadingZero) {
    const suggested = strippedZero.length === 9 ? strippedZero : (strippedZero || '256900117');
    return {
      isValid: false,
      cleanedNik: strippedZero,
      hasLeadingZero: true,
      isAbnormalLength,
      hasNonDigits,
      digitCount: digitsOnly.length,
      suggestedNik: suggested,
      noticeMessage: `Pemberitahuan NIK: NIK tidak boleh diawali angka nol (0). Harap mengisi NIK yang benar di input NIK tanpa angka nol di depan (contoh NIK benar: ${suggested}).`,
      errorMessage: `Pemberitahuan NIK: NIK tidak boleh diawali angka nol (0). Harap mengisi NIK yang benar di input NIK tanpa nol.`
    };
  }

  // Case 2: Contains letters or symbols
  if (hasNonDigits) {
    return {
      isValid: false,
      cleanedNik: digitsOnly,
      hasLeadingZero: false,
      isAbnormalLength: digitsOnly.length !== 9,
      hasNonDigits: true,
      digitCount: digitsOnly.length,
      suggestedNik: digitsOnly,
      errorMessage: `Peringatan: NIK hanya boleh berupa angka. Karakter "${nonDigits}" tidak valid.`
    };
  }

  // Case 3: Abnormal digit count (Must be exactly 9 digits)
  if (digitsOnly.length !== 9) {
    return {
      isValid: false,
      cleanedNik: digitsOnly,
      hasLeadingZero: false,
      isAbnormalLength: true,
      hasNonDigits: false,
      digitCount: digitsOnly.length,
      suggestedNik: digitsOnly,
      errorMessage: `Peringatan K3: Jumlah digit NIK abnormal (${digitsOnly.length} digit). Tidak boleh mengisi FTW! Format NIK wajib tepat 9 digit angka tanpa angka nol di depannya (contoh: 256900117 atau 266900047).`
    };
  }

  return {
    isValid: true,
    cleanedNik: digitsOnly,
    hasLeadingZero: false,
    isAbnormalLength: false,
    hasNonDigits: false,
    digitCount: 9,
    suggestedNik: digitsOnly
  };
}

/**
 * Checks if two NIK strings match, even if one has prefix "NIK" / "NRP", leading zeros, or spaces.
 * e.g., "NIK226900186" matches "226900186", "0226900186", "NRP-226900186".
 */
export function isNikMatch(nikA?: string, nikB?: string): boolean {
  if (!nikA || !nikB) return false;
  const a = normalizeNIK(nikA);
  const b = normalizeNIK(nikB);
  if (a === b) return true;

  const strippedA = a.replace(/^(NIK|NRP)/, '').replace(/^0+/, '');
  const strippedB = b.replace(/^(NIK|NRP)/, '').replace(/^0+/, '');
  if (strippedA.length > 0 && strippedA === strippedB) return true;

  // Substring match for badge numbers with length >= 5
  if (strippedA.length >= 5 && strippedB.length >= 5) {
    if (strippedA.includes(strippedB) || strippedB.includes(strippedA)) {
      return true;
    }
  }

  return false;
}

/**
 * Gets normalized WIB date YYYY-MM-DD from an FTWRecord.
 * Handles ISO (2026-09-26), DD/MM/YYYY, Indonesian text ("26 September 2026"), and timestamps.
 */
export function getRecordWibDate(record: FTWRecord): string {
  if (record.date) {
    const raw = String(record.date).trim();

    // 1. Format YYYY-MM-DD
    const isoMatch = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (isoMatch) {
      return `${isoMatch[1]}-${isoMatch[2].padStart(2, '0')}-${isoMatch[3].padStart(2, '0')}`;
    }

    // 2. Format DD-MM-YYYY or DD/MM/YYYY
    const ddmmyyyy = raw.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (ddmmyyyy) {
      return `${ddmmyyyy[3]}-${ddmmyyyy[2].padStart(2, '0')}-${ddmmyyyy[1].padStart(2, '0')}`;
    }

    // 3. Format Indonesian month e.g. "26 September 2026" or "26 Sep 2026"
    const textDate = raw.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if (textDate) {
      const day = textDate[1].padStart(2, '0');
      const mName = textDate[2].toLowerCase();
      const year = textDate[3];
      const month = INDO_MONTH_MAP[mName];
      if (month) {
        return `${year}-${month}-${day}`;
      }
    }
  }

  // 4. Derive from submittedAt if available
  if (record.submittedAt) {
    const d = new Date(record.submittedAt);
    if (!isNaN(d.getTime())) {
      const utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      const wib = new Date(utc + (3600000 * 7));
      const yyyy = wib.getFullYear();
      const mm = String(wib.getMonth() + 1).padStart(2, '0');
      const dd = String(wib.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    }
  }

  return record.date || '';
}

/**
 * Determines shift (1 or 2) from an FTWRecord.
 * - Shift 2 (Malam): Jam 15.00 sore - 03.59 subuh (Termasuk 16.00 - 18.00)
 * - Shift 1 (Siang): Jam 04.00 subuh - 14.59 siang
 */
export function getRecordShift(record: FTWRecord): 1 | 2 {
  if (record.shift !== undefined && record.shift !== null) {
    const str = String(record.shift).toLowerCase().trim();
    if (str === '2' || Number(record.shift) === 2 || /malam|night|shift 2|s2/i.test(str)) {
      return 2;
    }
    if (str === '1' || Number(record.shift) === 1 || /siang|pagi|day|shift 1|s1/i.test(str)) {
      return 1;
    }
  }

  // Derive from raw jam string if present
  if (record.jam) {
    const m = String(record.jam).match(/(\d{1,2})/);
    if (m) {
      const h = parseInt(m[1], 10);
      return (h >= 15 || h < 4) ? 2 : 1;
    }
  }

  // Derive from submittedAt if available
  if (record.submittedAt) {
    const d = new Date(record.submittedAt);
    if (!isNaN(d.getTime())) {
      const utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      const wib = new Date(utc + (3600000 * 7));
      const hr = wib.getHours();
      return (hr >= 15 || hr < 4) ? 2 : 1;
    }
  }

  return 1;
}

/**
 * Returns all FTW records submitted for a specific date and shift (or all shifts if shift is 'all' or undefined).
 */
export function getSubmittedFtwForDateAndShift(
  date: string,
  shift: 1 | 2 | 'all' | undefined,
  records: FTWRecord[]
): FTWRecord[] {
  if (!records || records.length === 0) return [];

  return records.filter(r => {
    const recDate = getRecordWibDate(r);
    if (recDate !== date) return false;

    if (!shift || shift === 'all') return true;
    const recShift = getRecordShift(r);
    return recShift === shift;
  });
}

/**
 * Resolves the FTW status of an operator for a specific date and optional shift.
 * Supports fallback matching by operator name and automatically honors valid FIT results
 * filled on that date even if shift field was slightly divergent.
 * 
 * Returns:
 * - 'fit': Operator filled FTW and was declared FIT (Label Hijau)
 * - 'unfit': Operator filled FTW and was declared UNFIT (Label Merah)
 * - 'pending': Operator has NOT filled FTW yet (Label Abu-abu)
 */
export function getOperatorFTW(
  nik: string | undefined,
  date: string,
  shift: 1 | 2 | undefined,
  records: FTWRecord[],
  operatorName?: string
): {
  status: FTWStatus;
  record?: FTWRecord;
} {
  if ((!nik && !operatorName) || !records || records.length === 0) {
    return { status: 'pending' };
  }

  // Normalize operator name for secondary fallback matching
  const cleanOpName = operatorName ? operatorName.trim().toUpperCase().replace(/\s+/g, ' ') : '';
  const opCoreName = cleanOpName.replace(/^(M\.|MUHAMMAD|MOHD|MD)\s+/i, '').trim();

  // Filter candidates matching this operator NIK (or Name) and target date
  const candidateRecords = records.filter(r => {
    const recDate = getRecordWibDate(r);
    const dateMatches = recDate === date || r.date === date;
    if (!dateMatches) return false;

    // 1. Primary match by NIK
    if (nik && isNikMatch(r.nik, nik)) return true;

    // 2. Specific aliases for Robiansyah / Rifky
    if (nik === '246900028' && r.nik === '246900003' && cleanOpName.includes('ROBIANSYAH')) return true;
    if (nik === '246900003' && r.nik === '246900028' && cleanOpName.includes('ROBIANSYAH')) return true;

    // 3. Secondary match by Operator Name if NIK didn't match or was formatted differently
    if (cleanOpName && r.name) {
      const recName = r.name.trim().toUpperCase().replace(/\s+/g, ' ');
      if (recName === cleanOpName) return true;
      if (recName.includes(cleanOpName) || cleanOpName.includes(recName)) return true;
      
      if (opCoreName && opCoreName.length >= 4) {
        const recCore = recName.replace(/^(M\.|MUHAMMAD|MOHD|MD)\s+/i, '').trim();
        if (recCore === opCoreName || recName.includes(opCoreName) || opCoreName.includes(recCore)) {
          return true;
        }
      }
    }

    return false;
  });

  if (candidateRecords.length === 0) {
    return { status: 'pending' };
  }

  // Sort candidate records by submission timestamp descending (most recent first)
  const sorted = [...candidateRecords].sort((a, b) => {
    const timeA = a.submittedAt ? new Date(a.submittedAt).getTime() : 0;
    const timeB = b.submittedAt ? new Date(b.submittedAt).getTime() : 0;
    return timeB - timeA;
  });

  // 1. Look for a record explicitly matching the requested shift
  let matched = sorted.find(r => {
    if (!shift) return true;
    const recShift = getRecordShift(r);
    return recShift === shift;
  });

  // 2. If no record for exact shift, check if operator has an active UNFIT or WAJIB ISTIRAHAT today
  if (!matched) {
    const criticalRisk = sorted.find(r => r.status === 'unfit' || r.status === 'rest');
    if (criticalRisk) {
      matched = criticalRisk;
    } else if (sorted.length > 0) {
      matched = sorted[0];
    }
  }

  if (matched) {
    const rawStatus = (matched.status as any);
    let resolvedStatus: FTWStatus = 'fit';
    if (rawStatus === 'unfit') resolvedStatus = 'unfit';
    else if (rawStatus === 'rest') resolvedStatus = 'rest';
    else if (rawStatus === 'conditional') resolvedStatus = 'conditional';
    else resolvedStatus = 'fit';

    return {
      status: resolvedStatus,
      record: matched
    };
  }

  return { status: 'pending' };
}

export interface FTWStyleConfig {
  status: FTWStatus;
  label: string;
  badgeLabel: string;
  description: string;
  badgeBg: string;
  chipBg: string;
  boxBorder: string;
  boxBg: string;
  dotColor: string;
  indicatorText: string;
  bannerBg: string;
  iconType: 'fit' | 'conditional' | 'rest' | 'unfit' | 'pending';
}

/**
 * Visual styling configuration corresponding to the user's color specifications:
 * - Fit -> Label Hijau (Emerald/Green)
 * - Pengawasan Khusus -> Label Kuning (Amber/Yellow)
 * - Wajib Istirahat -> Label Oranye (Orange)
 * - Unfit -> Label Merah (Rose/Red)
 * - Belum Mengisi -> Label Abu-abu (Gray/Slate)
 */
export function getFTWStyleConfig(status: FTWStatus): FTWStyleConfig {
  switch (status) {
    case 'fit':
      return {
        status: 'fit',
        label: 'FIT',
        badgeLabel: 'FIT TO WORK',
        description: 'Operator Fit Bekerja',
        badgeBg: 'bg-emerald-600 text-white font-black shadow-sm',
        chipBg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
        boxBorder: 'border-emerald-500 ring-1 ring-emerald-500/20',
        boxBg: 'bg-emerald-50/20',
        dotColor: 'bg-emerald-500',
        indicatorText: 'text-emerald-700',
        bannerBg: 'bg-emerald-600 border-emerald-700 text-white',
        iconType: 'fit'
      };

    case 'conditional':
      return {
        status: 'conditional',
        label: 'PENGAWASAN',
        badgeLabel: 'PENGAWASAN KHUSUS',
        description: 'Bekerja Dalam Pengawasan Khusus',
        badgeBg: 'bg-amber-400 text-slate-950 font-black shadow-sm',
        chipBg: 'bg-amber-50 text-amber-900 border-amber-300 font-bold',
        boxBorder: 'border-amber-400 ring-2 ring-amber-400/40',
        boxBg: 'bg-amber-50/30',
        dotColor: 'bg-amber-500',
        indicatorText: 'text-amber-800',
        bannerBg: 'bg-amber-400 border-amber-500 text-slate-950 font-black',
        iconType: 'conditional'
      };

    case 'rest':
      return {
        status: 'rest',
        label: 'WAJIB ISTIRAHAT',
        badgeLabel: 'WAJIB ISTIRAHAT',
        description: 'Wajib Istirahat Sebelum Bekerja',
        badgeBg: 'bg-rose-600 text-white font-black shadow-sm animate-pulse',
        chipBg: 'bg-rose-50 text-rose-950 border-rose-300 font-bold',
        boxBorder: 'border-rose-500 ring-2 ring-rose-500/50',
        boxBg: 'bg-rose-50/30',
        dotColor: 'bg-rose-600',
        indicatorText: 'text-rose-700',
        bannerBg: 'bg-rose-600 border-rose-700 text-white font-black animate-pulse',
        iconType: 'rest'
      };

    case 'unfit':
      return {
        status: 'unfit',
        label: 'UNFIT',
        badgeLabel: 'TIDAK BOLEH BEKERJA',
        description: 'Operator Unfit (Dilarang Bekerja)',
        badgeBg: 'bg-rose-600 text-white font-black shadow-sm animate-pulse',
        chipBg: 'bg-rose-50 text-rose-800 border-rose-300 font-bold',
        boxBorder: 'border-rose-500 ring-2 ring-rose-500/40',
        boxBg: 'bg-rose-50/30',
        dotColor: 'bg-rose-600',
        indicatorText: 'text-rose-700',
        bannerBg: 'bg-rose-600 border-rose-700 text-white font-black',
        iconType: 'unfit'
      };

    case 'pending':
    default:
      return {
        status: 'pending',
        label: 'BELUM ISI',
        badgeLabel: 'BELUM ISI FTW',
        description: 'Belum Mengisi Input FTW Online',
        badgeBg: 'bg-slate-400 text-white font-bold',
        chipBg: 'bg-slate-100 text-slate-600 border-slate-300',
        boxBorder: 'border-slate-300',
        boxBg: 'bg-slate-50/50',
        dotColor: 'bg-slate-400',
        indicatorText: 'text-slate-500',
        bannerBg: 'bg-slate-500 border-slate-600 text-white',
        iconType: 'pending'
      };
  }
}
